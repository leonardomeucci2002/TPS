const express=require("express");
const mysql=require("mySQL");
const fs=require("fs");
const bodyparser=require("body-parser");
const formidable = require('formidable');

const db =mysql.createConnection({
    host: "localhost",
    user: "root",
    password: "",
    database: "databasecloud"
});

db.connect((err) => {
    if(err){
        throw err;
    }
    console.log("Connected to database");
});

const app=express();

app.use(bodyparser.json());
app.use(bodyparser.urlencoded({
    extended: true
}));

app.get("/",(req, res) => {
    fs.readFile("Home.html", (err, data) => {
        if(err) throw err;
        res.writeHead(200, {"Content-Type": "text/html"});
        res.write(data);
        res.end();
    });

    /*let sql= `CREATE DATABASE databasecloud`;
    db.query(sql, (err, result) => {
        if(err) throw err;
        console.log(result);
        res.send("database created");
    });*/
});

app.post("/SignIn", (req, res) => {
    if(req.body.password==req.body.cpassword){
        console.log(`${req.body.email} ${req.body.username} ${req.body.password}`);

        sql= `SELECT * FROM Users`;
            db.query(sql, (err, result) => {
            console.log(result);
            //console.log(result[0].email);

            let v=false;
            console.log(Object.keys(result).length);
            for(c=0;c<Object.keys(result).length;c++){
                if(result[c].email==req.body.email || result[c].username==req.body.username){
                    v=true;
                }
            }
            
            if(v==false){
                sql= `INSERT INTO Users VALUES ('${req.body.email}', '${req.body.username}', '${req.body.password}')`;
                db.query(sql, (err, result) => {
                    console.log(result);
                    fs.mkdir(`./CloudDirectory/${req.body.username}`, (e) =>{});
                    fs.readFile("Home.html", (err, data) => {
                        if(err) throw err;
                        res.writeHead(200, {"Content-Type": "text/html"});
                        res.write(data);
                        res.end();
                    });
                });
            }else{
                fs.readFile("Home.html", (err, data) => {
                    if(err) throw err;
                    res.writeHead(200, {"Content-Type": "text/html"});
                    res.write(data+`<script>alert("nome utente o email gia esistenti")</script>`);
                    res.end();
                });
            }
        });
        

        
    }else{
        fs.readFile("Home.html", (err, data) => {
            if(err) throw err;
            res.writeHead(200, {"Content-Type": "text/html"});
            res.write(data+`<script>alert("I campi password e conferma password non sono uguali")</script>`);
            res.end();
        });
    }
});
let user;
app.post("/Login", (req, res) => {
    let sql = `SELECT * FROM Users`;
    db.query(sql, (err, result) => {
        let u = req.body.username;
        let p = req.body.password;

        let v=false;
        let ind;
        for(var c=0;c<Object.keys(result).length;c++){
            if(u==result[c].username && p==result[c].password){
                v=true;
                ind=c;
            }
        }

        if(v==true){
            console.log(result[ind].email);
            user=result[ind].username;
            fs.readFile("Logged.html", (err, data) => {
                if(err) throw err;
                res.writeHead(200, {"Content-Type": "text/html"});
                res.write(stampa(result, ind));
                res.end();
            });
        }else{
            fs.readFile("Home.html", (err, data) => {
                if(err) throw err;  
                res.writeHead(200, {"Content-Type": "text/html"});
                res.write(data+`<script>alert("Dati non validi")</script>`);
                res.end();
            });
        }
    });
});

app.post("/Upload?:usr", (req, res) => {
    let form = new formidable.IncomingForm();
    form.parse(req, function (err, fields, files) {
        var oldpath = files.filetoupload.path;
        var newpath = __dirname+`/CloudDirectory/${req.query.usr}/` + files.filetoupload.name;
        fs.rename(oldpath, newpath, function (err) {
          if (err) throw err;
        });
    });
    res.end();
});

app.get("/download", (req, res) => {
    fs.readFile(__dirname + `/CloudDirectory/${user}/` + req.query.file,(err, data) => {
        console.log(__dirname + `\\CloudDirectory\\${user}\\` + req.body.file);
        res.send(data);
        res.end();
    });
});

app.get("/CloudDirectory", (req, res) => {
    fs.readdir(`./CloudDirectory/${req.query.username}`, (err, list) => {
        output(list, res);
    });
});

const PORT=process.env.PORT || 3000;

app.listen(PORT,() => {
    console.log(`Server running on port ${PORT}`);
});



function stampa(result, ind){
    return `<!DOCTYPE html>
    <html>
        <head>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        </head>
        <body style="background-color: #e6e6e6">
            <div class="jumbotron" style="background-color: #cccccc">
                <h1 style="text-align: center; font-family: Georgia, serif">Node Cloud</h1>
                <h4 style="text-align: center; font-family: Georgia, serif">Benvenuto ${result[ind].username}</h4>
            </div>
            <div class="container" style="background-color: #f2f2f2; text-align: center">
                <ul class="nav nav-tabs">
                    <li class="nav-item">
                      <a class="nav-link active" data-toggle="tab" href="#See">I tuoi files</a>
                    </li>
                    <li class="nav-item">
                      <a class="nav-link" data-toggle="tab" href="#Upload">Carica un file</a>
                    </li>
                </ul>
    
                <div class="tab-content">
                    <div class="tab-pane active " id="See">
                        <h3 style="text-align: center">I tuoi files</h3>
                        <p><a target="_blank" href="http://172.20.31.32:3000/CloudDirectory?username=${result[ind].username}">Premi per visualizzare i file</a></p>
                        <form action="/download" method="get" enctype="multipart/form-data">
                            <input type="text" name="file">
                            <input type="submit">
                        </form>
                    </div>
                    <div class="tab-pane " id="Upload">
                        <p><br><br></p>
                            <form action="/Upload?usr=${result[ind].username}" method="post" enctype="multipart/form-data">
                                <table border="2" align="center">
                                    <tr>
                                        <td style="border-color: transparent; text-align: center">
                                            <h3>Upload File</h3>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>
                                            <input type="file" name="filetoupload">
                                        </td>
                                    </tr>
                                    <tr>
                                        <td style="border-color: transparent; text-align: center">
                                            <input type="submit">
                                        </td>
                                    </tr>
                                </table> 
                            </form>
                        <p><br><br><br><br><br><br><br></p>
                    </div>
                </div>
            </div>
        </body>
    </html>`;
}

function output(list, res){
    let text=`<!DOCTYPE html>
    <html>
        <head>
            <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
            <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.0/jquery.min.js"></script>
            <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
            <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        </head>
        <body style="background-color: #e6e6e6">
            <div class="jumbotron" style="background-color: #cccccc">
                <h1 style="text-align: center; font-family: Georgia, serif">Node Cloud</h1>
                <h4 style="text-align: center; font-family: Georgia, serif">I tuoi files</h4>
            </div>
            <div class="container" style="background-color: #f2f2f2; text-align: center">`;
    for(var c=0;c<list.length;c++){
        text+=`<p>${list[c]}</p>`;
    }

    text+=`</div></body></html>`;
    res.writeHead(200, {"Content-Type": "text/html"});
    res.write(text);
    res.end();
}