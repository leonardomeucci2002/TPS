﻿<!DOCTYPE html>
<html lang="ita" xmlns:o="urn:schemas-microsoft-com:office:office"
	xmlns:x="urn:schemas-microsoft-com:office:excel"
	xmlns="http://www.w3.org/TR/REC-html40">

    <!-- Basic -->
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">   
   
    <!-- Mobile Metas -->
    <meta name="viewport" content="width=device-width, minimum-scale=1.0, maximum-scale=1.0, user-scalable=no">
 
     <!-- Site Metas -->
    <title>Stage agomir Santucci</title>  
    <meta name="keywords" content="">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Site CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Responsive CSS -->
    <link rel="stylesheet" href="css/responsive.css">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="css/custom.css">
	<script src="js/modernizr.js"></script> <!-- Modernizr -->
	
	<!--connessione al file excel-->
	<meta http-equiv=Content-Type content="text/html; charset=windows-1252">
	<meta name=ProgId content=Excel.Sheet>
	<meta name=Generator content="Microsoft Excel 15">
	<link rel=File-List href="excelfile_file/filelist.xml">
	<style id="bo_19415_Styles">
	table{mso-displayed-decimal-separator:"\,";
		mso-displayed-thousand-separator:"\.";}
	.xl1519415
		{padding-top:1px;
		padding-right:1px;
		padding-left:1px;
		mso-ignore:padding;
		color:black;
		font-size:9.0pt;
		font-weight:400;
		font-style:normal;
		text-decoration:none;
		font-family:Arial, sans-serif;
		mso-font-charset:0;
		mso-number-format:General;
		text-align:general;
		vertical-align:bottom;
		mso-background-source:auto;
		mso-pattern:auto;
		white-space:nowrap;
		}
	.imgprofilo{
		border-radius: 50% 50% 50% 50%; 
	}
	</style>

	<script language="Javascript1.3">
		import flash.filesystem.*; 
		
		private function inizia():void {
		// Recupera il file dalla cartella Documenti
		var file = File.documentsDirectory.resolvePath(“hey.txt”);

		// Crea un oggetto fileStream e apre il file in sola lettura
		var stream:FileStream = new FileStream();
		stream.openAsync( file, FileMode.READ );

		// Imposta l’evento in modo che quando il file è caricato venga eseguita la funzione analizza
		stream.addEventListener( Event.COMPLETE, analizza );
		}
		
		

		private function analizza( evt:Event ):void {
		// Recupera il file che ha lanciato l’evento come oggetto FileStream
		var stream:FileStream = evt.target as FileStream;

		// Ne legge il contenuto e lo memorizza come stringa
		var contenuti:String = stream.readUTFBytes(stream.bytesAvailable);
		
		// il testo viene mostrato in un campo di testo
		testo.text = contenuti;

		// L’oggetto FileStram viene chiuso
		stream.close();
		}
	</script> 

	<script>
		function myFunction() {
			var x;
			var temp=new Array();
			for(x=1;x<4;x++){
				temp="demo1["+x+"]";
				document.getElementById(temp).innerHTML = nome[ncommenti-x];
				temp="demo2["+x+"]";
				document.getElementById(temp).innerHTML = cognome[ncommenti-x];
				temp="demo3["+x+"]";
				document.getElementById(temp).innerHTML = contenuto[ncommenti-x];
				temp="demo4["+x+"]";
				document.getElementById(temp).innerHTML = lavoro[ncommenti-x];
				temp="demo5["+x+"]";
				document.getElementById(temp).innerHTML = sesso[ncommenti-x];
				temp="demo6["+x+"]";
				document.getElementById(temp).innerHTML = eta[ncommenti-x];
			}
		}
	</script>
	<?php
	
	/* dichiariamo alcune importanti variabili per collegarci al database */
	$host = "localhost";
	$dbusername = "root";
	$dbname = "dbsito";

	// Create connection
	$conn = mysqli_connect($host, $dbusername, '', $dbname);
	// Check connection
	if (!$conn) {
		die("Connection failed: " . mysqli_connect_error());
	}

	$sql = "SELECT nome,cognome,contenuto,lavoro,sesso,eta FROM commenti";
	$result = mysqli_query($conn, $sql);
	$ncommenti=mysqli_affected_rows($conn);

	$cont=0;
	// output data of each row
	while($row = mysqli_fetch_assoc($result)) {
		
		$nome[$cont]=$row["nome"];
		$cognome[$cont]=$row["cognome"];
		$contenuto[$cont]=$row["contenuto"];
		if($row["lavoro"]==0){
			$lavoro[$cont]="- studente";
		}
		if($row["lavoro"]==1){
			$lavoro[$cont]="- lavoratore";
		}
		if($row["lavoro"]==2){
			$lavoro[$cont]="- pensionato";
		}
		if($row["sesso"]==0){
			$sesso[$cont]="Uomo";
		}
		if($row["sesso"]==1){
			$sesso[$cont]="Donna";
		}
		if($row["sesso"]==2){
			$sesso[$cont]="Trans";
		}

		$eta[$cont]=$row["eta"];

		$cont++;

	}

	mysqli_close($conn);
	echo '
	<script type="text/javascript">

	var ncommenti=' . json_encode($ncommenti) . ';
	var y;
	var nome=new Array();
	var cognome=new Array();
	var contenuto=new Array();
	var lavoro=new Array();
	var sesso=new Array();
	var eta=new Array();

	nome = ' . json_encode($nome) . ';
	cognome= ' . json_encode($cognome) . ';
	contenuto= ' . json_encode($contenuto) . ';
	lavoro= ' . json_encode($lavoro) . ';
	sesso= ' . json_encode($sesso) . ';
	eta= ' . json_encode($eta) . ';

	</script>';
	?>
</head>
<body id="page-top" class="politics_version" onload="myFunction()">

    <!-- LOADER -->
    <div id="preloader">
        <div id="main-ld">
			<div id="loader"></div>  
		</div>
    </div><!-- end loader -->
    <!-- END LOADER -->
	
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top" id="mainNav">
      <div class="container">
        <a class="navbar-brand js-scroll-trigger" href="#page-top">
			<img class="img-fluid" src="images/logo.png" alt="" />
		</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          Menu
          <i class="fa fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav text-uppercase ml-auto">
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger active" href="#home">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#about">CHI SIAMO</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#services">ATTIVIT&Aacute SVOLTE</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#portfolio">FOTO</a>
            </li>
            <li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#testimonials">COMMENTI</a>
            </li>
			<li class="nav-item">
              <a class="nav-link js-scroll-trigger" href="#contact">LASCIA UN COMMENTO</a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
	
	<section id="home" class="main-banner parallaxie" style="background: url('uploads/banner-01.jpg')">
		<div class="heading">
			<h1>Stage Agomir</h1>
			<p>Meucci Leonardo e Santaniello Silvio</p>
			<h3 class="cd-headline clip is-full-width">			
				<span class="cd-words-wrapper">
					<b class="is-visible">"Cambiare prospettiva"</b>
					<b>"Uscire dagli schemi"</b>
					<b>"Adattarsi ai cambiamenti"</b>
				</span>
			</h3>
		</div>
	</section>

	<svg id="clouds" class="hidden-xs" xmlns="http://www.w3.org/2000/svg" version="1.1" width="100%" height="100" viewBox="0 0 85 100" preserveAspectRatio="none">
        <path d="M-5 100 Q 0 20 5 100 Z
            M0 100 Q 5 0 10 100
            M5 100 Q 10 30 15 100
            M10 100 Q 15 10 20 100
            M15 100 Q 20 30 25 100
            M20 100 Q 25 -10 30 100
            M25 100 Q 30 10 35 100
            M30 100 Q 35 30 40 100
            M35 100 Q 40 10 45 100
            M40 100 Q 45 50 50 100
            M45 100 Q 50 20 55 100
            M50 100 Q 55 40 60 100
            M55 100 Q 60 60 65 100
            M60 100 Q 65 50 70 100
            M65 100 Q 70 20 75 100
            M70 100 Q 75 45 80 100
            M75 100 Q 80 30 85 100
            M80 100 Q 85 20 90 100
            M85 100 Q 90 50 95 100
            M90 100 Q 95 25 100 100
            M95 100 Q 100 15 105 100 Z">
        </path>
    </svg>

    <div id="about" class="section wb">
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                    <div class="message-box">                        
                        <h2>Chi siamo</h2>
                        <p>Meucci Leonardo e Santaniello Silvio, due studenti Badoniani frequentanti la quarta A informatica. </p>
						<p>Dal 27/01/2020 al 07/02/2020 abbiamo effettuato il primo periodo di stage presso l'azienda informatica Agomir Lecco.</p>

                        <a href="cvml.pdf" class="sim-btn btn-hover-new" data-text="Download CV" download><span>Download CV M.L.</span></a>
 			            <a href="cvss.pdf" class="sim-btn btn-hover-new" data-text="Download CV" download><span>Download CV S.S.</span></a>
                    </div><!-- end messagebox -->
                </div><!-- end col -->

                <div class="col-md-6">
                    <div class="right-box-pro wow fadeIn">
                        <img src="uploads/about_04.jpeg" alt="" class="img-fluid img-rounded">
                    </div><!-- end media -->
                </div><!-- end col -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->
	
    <div id="services" class="section lb">
        <div class="container">
            <div class="section-title text-left">
                <h3>Attivit&agrave svolte</h3>
                <p>Primo periodo di stage</p>
            </div><!-- end title -->
				
				
            <div class="row">
				<div class="col-md-4">
                    <div class="services-inner-box">
						<div class="ser-icon">
							<a href="crezioneexcelljs.php"><img src="1.png" height="50" width="50"></a>
						</div>
						<h2>Database Excel</h2>
						<p>Creazione e importazione di dati finalizzati alla creazione di database utilizzando i fogli di calcolo di Excel.</p>
					</div>
                </div><!-- end col -->
				
                <div class="col-md-4">
                    <div class="services-inner-box">
						<div class="ser-icon">
							<a href="ciao.pbix"><img src="2.jpg" height="50" width="50"></a>
						</div>
						<h2>PowerBI</h2>
						<p>Caricamento database da excel su powerBI con successiva elaborazione dei dati per la creazione di grafici e statistiche.</p>
					</div>
                </div><!-- end col -->
				
				<div class="col-md-4">
                    <div class="services-inner-box">
						<div class="ser-icon">
							<a href="droni"><img src="3.png" height="50" width="50"></a>
						</div>
						<h2 >Droni</h2>
						<p>Studio delle tipologie e delle funzionalita dei droni.</br>Ricerca delle loro applicazionioni in ambito informatico.</p>
					</div>
                </div><!-- end col -->
			</div><!-- end row -->
			
			<div class="row">
				<div class="col-md-4">
                    <div class="services-inner-box">
						<div class="ser-icon">
							<a href="domotica"><img src="4.png" height="50" width="50"></a>
						</div>
						<h2>Domotica</h2>
						<p>Ricerca delle tecnologie adatte e delle possibili applicazioni dell'informatica e dell'elettronica nella gestione delle abitazioni.</p>
					</div>
                </div><!-- end col -->

				<div class="col-md-4">
                    <div class="services-inner-box">
						<div class="ser-icon">
							<a href="iot"><img src="5.png" height="50" width="50"></a>
						</div>
						<h2>I.O.T.</h2>
						<p>Tecnologie per collegare a Internet qualunque tipo di apparato. Al fine di monitorare, controllare e trasferire informazioni.</p>
					</div>
                </div><!-- end col -->
			</div><!-- end row -->
			
        </div><!-- end container -->
    </div><!-- end section -->
	
	<div id="portfolio" class="section lb">
		<div class="container">
			<div class="section-title text-left">
                <h3>Foto</h3>
                <p>Fotografie riguardanti gli strumenti utilizzati e gli ambienti lavorativi.</p>
            </div><!-- end title -->
			
			<div class="gallery-menu row">
				<div class="col-md-12">
					<div class="button-group filter-button-group text-left">
						<button class="active" data-filter="*">Tutto</button>
						<button data-filter=".gal_a">Ambiente lavorativo</button>
						<button data-filter=".gal_b">Strumenti utilizzati</button>
						<button data-filter=".gal_c">Approfondimenti</button>
					</div>
				</div>
			</div>
			
			<div class="gallery-list row">
				<div class="col-md-4 col-sm-6 gallery-grid gal_a">
					<div class="gallery-single fix">
						<img src="uploads/gallery_img-01.jpg" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<a href="uploads/gallery_img-01.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_a">
					<div class="gallery-single fix">
						<img src="uploads/gallery_img-02.jpg" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<a href="uploads/gallery_img-02.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>

				<div class="col-md-4 col-sm-6 gallery-grid gal_a">
					<div class="gallery-single fix">
						<img src="uploads/gallery_img-11.jpg" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<a href="uploads/gallery_img-11.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>

				<div class="col-md-4 col-sm-6 gallery-grid gal_a">
					<div class="gallery-single fix">
						<img src="uploads/gallery_img-09.jpg" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<a href="uploads/gallery_img-09.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>

				<div class="col-md-4 col-sm-6 gallery-grid gal_b">
					<div class="gallery-single fix">
						<img src="uploads/gallery_img-03.jpg" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<a href="uploads/gallery_img-03.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_b">
					<div class="gallery-single fix">
						<img src="uploads/gallery_img-04.jpg" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<a href="uploads/gallery_img-04.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_b">
					<div class="gallery-single fix">
						<img src="uploads/gallery_img-05.jpg" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<a href="uploads/gallery_img-05.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>
				
				<div class="col-md-4 col-sm-6 gallery-grid gal_c">
					<div class="gallery-single fix">
						<img src="uploads/gallery_img-06.jpg" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<a href="uploads/gallery_img-06.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>

				<div class="col-md-4 col-sm-6 gallery-grid gal_c">
					<div class="gallery-single fix">
						<img src="uploads/gallery_img-07.jpg" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<a href="uploads/gallery_img-07.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>

				<div class="col-md-4 col-sm-6 gallery-grid gal_c">
					<div class="gallery-single fix">
						<img src="uploads/gallery_img-10.jpg" class="img-fluid" alt="Image">
						<div class="img-overlay">
							<a href="uploads/gallery_img-10.jpg" data-rel="prettyPhoto[gal]" class="hoverbutton global-radius"><i class="fa fa-picture-o"></i></a>
						</div>
					</div>
				</div>

			</div>
			</div>
		</div>
	</div>

	<div id="testimonials" class="section wb">
        <div class="container">
            <div class="section-title text-left">
                <h3>Commenti</h3>
                <p>I vostri commenti possono aiutarci a crescere.</p>
                <p>Qui verranno mostarti solo gli ultimi 3 commenti.</p>
            </div>

            
            <div class="col-md-12 col-sm-12">
				<div class="testimonial clearfix">
					<div class="desc">
					<h3><i class="fa fa-quote-left"></i><a id="demo5[1]">temp</a><a> </a><a id="demo6[1]">temp</a><a> anni</a></h3>
						<p class="lead" id="demo3[1]">temp</p>
					</div>
					<div class="testi-meta">
						<?php  
						//recupero img

						/* dichiariamo alcune importanti variabili per collegarci al database */
						$host = "localhost";
						$dbusername = "root";
						$dbname = "dbsito";

						// Create connection
						$conn = mysqli_connect($host, $dbusername, '', $dbname);
						// Check connection
						if (!$conn) {
							die("Connection failed: " . mysqli_connect_error());
						}

						$sql = "SELECT img FROM commenti";
						$result = mysqli_query($conn, $sql);
						$ncommenti=mysqli_affected_rows($conn);
						$cont=0;

						// output data of each row
						while($row = mysqli_fetch_assoc($result)) {
							$cont++;
							if($ncommenti==$cont){
								echo '  
								<img src="data:image/jpeg;base64,'.base64_encode($row['img'] ).'" height="50" width="50" style="border-radius: 50% 50% 50% 50%; " class="img-fluid alignleft"/>  
							';  
							}
						}
						?> 
						
						<h4><a id="demo1[1]">temp</a><a> </a><a id="demo2[1]">temp</a> <small id="demo4[1]">temp</small></h4>
					</div>
				</div>
				</br>

				<div class="testimonial clearfix">
					<div class="desc">
					<h3><i class="fa fa-quote-left"></i><a id="demo5[2]">temp</a><a> </a><a id="demo6[2]">temp</a><a> anni</a></h3>
						<p class="lead" id="demo3[2]">temp</p>
					</div>
					
					<div class="testi-meta">
						<?php  
						//recupero img

						/* dichiariamo alcune importanti variabili per collegarci al database */
						$host = "localhost";
						$dbusername = "root";
						$dbname = "dbsito";

						// Create connection
						$conn = mysqli_connect($host, $dbusername, '', $dbname);
						// Check connection
						if (!$conn) {
							die("Connection failed: " . mysqli_connect_error());
						}

						$sql = "SELECT img FROM commenti";
						$result = mysqli_query($conn, $sql);
						$ncommenti=mysqli_affected_rows($conn);
						$cont=0;

						// output data of each row
						while($row = mysqli_fetch_assoc($result)) {
							$cont++;
							if($ncommenti==($cont+1)){
								echo '  
								<img src="data:image/jpeg;base64,'.base64_encode($row['img'] ).'" height="50" width="50" style="border-radius: 50% 50% 50% 50%; " class="img-fluid alignleft"/>  
							';  
							}
						}
						?> 
						<h4><a id="demo1[2]">temp</a><a> </a><a id="demo2[2]">temp</a> <small id="demo4[2]">temp</small></h4>
					</div>
					<!-- end testi-meta -->
				</div>
				</br>

				<div class="testimonial clearfix">
					<div class="desc">
					<h3><i class="fa fa-quote-left"></i><a id="demo5[3]">temp</a><a> </a><a id="demo6[3]">temp</a><a> anni</a></h3>
						<p class="lead" id="demo3[3]">temp</p>
					</div>
					
					<div class="testi-meta">
						<?php  
						//recupero img

						/* dichiariamo alcune importanti variabili per collegarci al database */
						$host = "localhost";
						$dbusername = "root";
						$dbname = "dbsito";

						// Create connection
						$conn = mysqli_connect($host, $dbusername, '', $dbname);
						// Check connection
						if (!$conn) {
							die("Connection failed: " . mysqli_connect_error());
						}

						$sql = "SELECT img FROM commenti";
						$result = mysqli_query($conn, $sql);
						$ncommenti=mysqli_affected_rows($conn);
						$cont=0;

						// output data of each row
						while($row = mysqli_fetch_assoc($result)) {
							$cont++;
							if($ncommenti==($cont+2)){
								echo '  
								<img src="data:image/jpeg;base64,'.base64_encode($row['img'] ).'" height="50" width="50" style="border-radius: 50% 50% 50% 50%; " class="img-fluid alignleft"/>  
							';  
							}
						}
						?> 
						<h4><a id="demo1[3]">temp</a><a> </a><a id="demo2[3]">temp</a> <small id="demo4[3]">temp</small></h4>
					</div>
				</div>
				</br>
            </div>
        </div>
    </div>
	
    <div id="contact" class="section db">
        <div class="container">
            <div class="section-title text-left">
                <h3>Lascia un commento</h3>
                <p>Lascia una recensione, un opinione o un consiglio.</p>
            </div><!-- end title -->

            <div class="row" id="primo">
                <div class="col-md-12">
					<form class="contact_form" method="post" action="commenti.php"  enctype="multipart/form-data">
						<div id="message"></div>
						<form id="contactForm" name="sentMessage" novalidate="novalidate">
							<div class="row">
							
								<div class="col-md-6">
									<div class="form-group">
										<input class="form-control" name="nome" id="nome" placeholder="Nome" required="required">
										<p class="help-block text-danger"></p>
									</div>
									<div class="form-group">
										<input class="form-control" name="cognome" id="cognome" placeholder="Cognome" required="required">
										<p class="help-block text-danger"></p>
									</div>
									<div class="form-group">
											<select class="form-control" name="sesso" id="sesso" placeholder="Sesso" required="required" style="height:50px">
												<option value="0">Maschio</option>
												<option value="1">Femmina</option>
												<option value="2">Non meglio definibile</option>
											</select>
										<p class="help-block text-danger"></p>
									</div>
									<div class="form-group">
										<input class="form-control" name="eta" id="eta" placeholder="Età" required="required">
										<p class="help-block text-danger"></p>
									</div>
									<div class="form-group">
										<input class="form-control" name="email" id="email" placeholder="Email" required="required">
										<p class="help-block text-danger"></p>
									</div>
								</div>
								
								<div class="col-md-6">

									<div class="form-group">
									<p>Selezione immagine profilo</p>
										<input type="file" name="image" id="image"/> 
									</div> 

									<div class="form-group">
										<select class="form-control" name="lavoro" id="lavoro" placeholder="Lavoro" required="required" style="height:50px">
											<option value="0">Studente</option>
											<option value="1">Lavoratore</option>
											<option value="2">Pensionato</option>
										</select>
										<p class="help-block text-danger"></p>
									</div>
									<div class="form-group">
										<textarea class="form-control" name="messaggioid" id="messaggioid" placeholder="Commento" required="required"></textarea>
										<p class="help-block text-danger"></p>
									</div>
								</div>

								<div class="clearfix"></div>
								<div class="col-lg-12 text-center">
									<div id="success"></div>
									<button id="sendMessageButton" class="sim-btn" data-text="Send Message" type="submit">Invia</button>
								</div>
							</div>
						</form>
					</form>
                </div><!-- end col -->
            </div><!-- end row -->
        </div><!-- end container -->
    </div><!-- end section -->


    <div class="copyrights">

        <div class="container">
            <div class="footer-distributed">
                <div class="footer-left">
                    <p class="footer-company-name">Tutti i diritti riservati. 2020 <a href="#">Santucci</a></br> Sito creato da : Meucci Leonardo e Santaniello Silvio</p>
                	</br></br>
			<div class="immagine">
				<div class="google-maps">
					<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2778.7497350824965!2d9.405216906102131!3d45.856307820988256!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47841d2b349c2b85%3A0xa61b1fd9ec258cf!2sAgomir%20S.p.A.!5e0!3m2!1sit!2sit!4v1580382351740!5m2!1sit!2sit" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
				</div>
			</div>
		</div>

		<div class="footer-right">


			<div class="container" >
				<div class="row"  id="secondo">
					<div class="col-md-6 col-md-offset-3">
						<h1 class="page-header text-center" style="color:white">Contattataci</h1>
						<form class="form-horizontal" role="form" method="post" action="email.php">
							<div class="form-group">
								<label for="name" class="col-sm-2 control-label">Nome</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" id="mnome" name="mnome" placeholder="Nome">
								</div>
							</div>
							<div class="form-group">
								<label for="email" class="col-sm-2 control-label">Email</label>
								<div class="col-sm-10">
									<input type="email" class="form-control" id="memail" name="memail" placeholder="EMail" >
								</div>
							</div>
							<div class="form-group">
								<label for="name" class="col-sm-2 control-label">Oggetto</label>
								<div class="col-sm-10">
									<input type="text" class="form-control" id="moggetto" name="moggetto" placeholder="Oggetto" >
								</div>
							</div>
							<div class="form-group">
								<label for="message" class="col-sm-2 control-label">Messaggio</label>
								<div class="col-sm-10">
									<textarea class="form-control" rows="4" name="mmessaggio" style="width:400px;"></textarea>
								</div>
							</div>
							<div class="form-group">
								<div class="col-sm-10 col-sm-offset-2">
									<input id="submit" name="submit" type="submit" value="Invia" >
								</div>
							</div>
						</form> 
					</div>
				</div>
			</div>   

		</div><!-- end container -->
    </div><!-- end copyrights -->

    <a href="#" id="scroll-to-top" class="dmtop global-radius"><i class="fa fa-angle-up"></i></a>

    <!-- ALL JS FILES -->
    <script src="js/all.js"></script>
	<!-- Camera Slider -->
	<script src="js/jquery.mobile.customized.min.js"></script>
	<script src="js/jquery.easing.1.3.js"></script> 
	<script src="js/parallaxie.js"></script>
	<script src="js/headline.js"></script>
	<!-- Contact form JavaScript -->
    <script src="js/jqBootstrapValidation.js"></script>
    <script src="js/contact_me.js"></script>
    <!-- ALL PLUGINS -->
    <script src="js/custom.js"></script>
    <script src="js/jquery.vide.js"></script>

</body>
</html>