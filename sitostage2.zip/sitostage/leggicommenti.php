<?php
/* dichiariamo alcune importanti variabili per collegarci al database */
$host = "localhost";
$dbusername = "root";
$dbname = "dbsito";


// Create connection
$conn = mysqli_connect($host, $dbusername, '', $dbname);
// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT nome,cognome,commento FROM commenti";
$result = mysqli_query($conn, $sql);

// output data of each row
while($row = mysqli_fetch_assoc($result)) {
    //confronta con dati nel database
    if($row["tipo"]==$tipo && $row["codice"]==$codice){
        echo "ciao";
    }
}
if($cont==0){
    echo "Le credenziali inserite non sono valide";
}

mysqli_close($conn);
?>